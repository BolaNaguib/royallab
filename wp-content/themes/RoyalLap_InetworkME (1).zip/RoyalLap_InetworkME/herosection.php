<section id="" class="section__inner
                hero_type_resources_size_m" style="
background-image: linear-gradient(to bottom right, #ffffff1f, black),url(<?php the_field('hero_background'); ?>);
color: #fff;
background-size: cover;">

  <!-- START .uk-container -->
  <div class="uk-container
              uk-container-small
              uk-text-center">
        <div class="uk-text-center">
          <h1 class="uk-remove-margin hero__title "><?php the_field('hero_title'); ?></h1>
          <hr class="hr hr_margin_auto hr_border_white">

          <p class="" style="color: #ffffff;"><?php the_field('hero_caption'); ?></p>
        </div>
  </div> <!-- END .uk-container -->
</section>
