<?php include'header.php'; ?>

      <section id="herosection" class="hero
                      hero_type_resources_size_m" style="
    background-image: linear-gradient(to bottom right, #ffffff1f, black),url(img/mewall.jpg);
    color: #fff;
    background-size: cover;">

        <!-- START .uk-container -->
        <div class="uk-container
                    uk-container-small
                    uk-text-center">
 <div class="uk-grid">
   <div class="uk-width-1-1" >
     <div class="uk-text-center" style="
         padding: 250px 0px;
     ">
           <h1 class="uk-remove-margin" style="
           font-size: 10em;
color: #ffc600;
border: 2px dashed;
border-radius: 20px;
background-color: #00000075;
box-shadow: 10px 10px;
">16064</h1>
           <h1 class="uk-margin-remove" style="color: #ffffff;
    background-color: #2c5dad;
    padding: 10px;
    border: 2px dashed #ffffff;
    border-radius: 14px;"> Hotline</h1>
          </div>

   </div>


 </div>







            </div> <!-- END .uk-container -->
      </section>

<section class="section">
  <div class="uk-container">
    <div class="uk-grid " uk-grid="masonry: true">

      <div class="uk-width-1-2" uk-scrollspy="cls: uk-animation-fade;" >
        <div class="uk-card uk-card-default card uk-padding-small">
          <div class="uk-text-center">
            <h2 class="card_title">Lab to Lab</h2>
            <hr class="hr hr_margin_auto">
          </div>

          <ul class="uk-list uk-list-striped">

  <li><a href="labtolab.php">Lab to Lab call center</a></li>
  <li><a href="contactus.php">Test Result</a></li>
  <li><a href="contactus.php">Technical Complaints</a></li>
  <li><a href="contactus.php">Managerial Complaints</a></li>
  <li><a href="contactus.php">Register your data for contacting</a></li>
  <a class="card_link" href="labtolab.php"> Learn More</a>
          </ul>
        </div>

      </div>
      <div class="uk-width-1-2"  uk-scrollspy="cls: uk-animation-fade;">
        <img src="img/lap01.gif" alt="">
      </div>
      <div class="uk-width-1-2"  uk-scrollspy="cls: uk-animation-fade;">
        <div class="uk-card uk-card-default card uk-padding-small">
          <div class="uk-text-center">
            <h2 class="card_title">Corporate services</h2>
            <hr class="hr hr_margin_auto">
          </div>

          <ul class="uk-list uk-list-striped">

  <li><a href="contactus.php">contracts and corporation</a></li>
  <li><a href="contactus.php">corporate offers</a></li>
  <li><a href="videos.php">videos</a></li>
  <a class="card_link" href="contactus.php"> Learn More</a>

          </ul>
        </div>

      </div>


      <div class="uk-width-1-2"  uk-scrollspy="cls: uk-animation-fade;">
        <div class="uk-card uk-card-default card uk-padding-small">
          <div class="uk-text-center">
            <h2 class="card_title">Branches</h2>
            <hr class="hr hr_margin_auto">
          </div>

          <ul class="uk-list uk-list-striped">

  <li><a href="branches.php">Check Out Our Branches</a></li>
  <a class="card_link" href="branches.php"> Learn More</a>

          </ul>
        </div>

      </div>
    </div>
  </div>
</section>

<section class="uk-card-primary"  uk-scrollspy="cls: uk-animation-fade;" >
<div class="uk-container">
  <div class="uk-clearfix">
    <div class="uk-align-left uk-margin-remove uk-padding uk-padding-remove-horizontal uk-text-left">
      <h2 class="uk-margin-remove">Keep in touch and check our continuous offers
</h2>
    </div>
    <div class="uk-align-right uk-margin-remove uk-padding uk-padding-remove-horizontal uk-text-right">
      <h2 class="uk-margin-remove">    <button class="uk-button uk-button-default ">View Now
</button>
</h2>

    </div>
  </div>
</div>
</section>


<section class="section"  uk-scrollspy="cls: uk-animation-fade;">
  <div class="uk-container">
    <div uk-slider="center: true">

    <div class="uk-position-relative uk-visible-toggle uk-light">

        <ul class="uk-slider-items uk-child-width-1-2@s uk-grid">
            <li>
                <div class="uk-card uk-card-default">
                    <div class="uk-card-media-top">
                        <img src="img/slide1.jpg" alt="">
                    </div>
                    <div class="uk-card-body">
                      <h3 class="uk-card-title"> Website Launch</h3>
                      <p>We Would Like To Announce our website launch.</p>
                      <button class="button uk-button uk-button-default uk-padding-remove" style="color:#000;">Read More <span uk-icon="icon:  sign-in"></span></button>
                    </div>
                </div>
            </li>
            <li>
                <div class="uk-card uk-card-default">
                    <div class="uk-card-media-top">
                        <img src="img/slide1.jpg" alt="">
                    </div>
                    <div class="uk-card-body">
                      <h3 class="uk-card-title"> Website Launch</h3>
                      <p>We Would Like To Announce our website launch.</p>
                      <button class="button uk-button uk-button-default uk-padding-remove" style="color:#000;">Read More <span uk-icon="icon:  sign-in"></span></button>
                    </div>
                </div>
            </li>
            <li>
                <div class="uk-card uk-card-default">
                    <div class="uk-card-media-top">
                        <img src="img/slide1.jpg" alt="">
                    </div>
                    <div class="uk-card-body">
                        <h3 class="uk-card-title"> Website Launch</h3>
                        <p>We Would Like To Announce our website launch.</p>
                      <button class="button uk-button uk-button-default uk-padding-remove" style="color:#000;">Read More <span uk-icon="icon:  sign-in"></span></button>
                    </div>
                </div>
            </li>
            <li>
                <div class="uk-card uk-card-default">
                    <div class="uk-card-media-top">
                        <img src="img/slide1.jpg" alt="">
                    </div>
                    <div class="uk-card-body">
                        <h3 class="uk-card-title"> Website Launch</h3>
                        <p>We Would Like To Announce our website launch.</p>
                      <button class="button uk-button uk-button-default uk-padding-remove" style="color:#000;">Read More <span uk-icon="icon:  sign-in"></span></button>
                    </div>
                </div>
            </li>
            <li>
                <div class="uk-card uk-card-default">
                    <div class="uk-card-media-top">
                        <img src="img/slide1.jpg" alt="">
                    </div>
                    <div class="uk-card-body">
                        <h3 class="uk-card-title"> Website Launch</h3>
                        <p>We Would Like To Announce our website launch.</p>
                      <button class="button uk-button uk-button-default uk-padding-remove" style="color:#000;">Read More <span uk-icon="icon:  sign-in"></span></button>
                                        </div>
                </div>
            </li>
        </ul>

        <a class="prev_slide uk-position-center-left uk-position-small uk-hidden-hover" href="#" uk-slidenav-previous uk-slider-item="previous"></a>
        <a class="next_slide uk-position-center-right uk-position-small uk-hidden-hover" href="#" uk-slidenav-next uk-slider-item="next"></a>

    </div>

    <ul class="uk-slider-nav uk-dotnav uk-flex-center uk-margin"></ul>

</div>
  </div>
</section>


<section class="section section_color_gray">
  <div class="uk-container">
    <div class="uk-text-center">
      <h1>Live Healthy</h1>
      <hr class="hr hr_margin_auto">
    </div>
    <br>

    <div class="uk-grid" >
      <div class="uk-width-1-3 uk-margin-remove"  uk-scrollspy="cls: uk-animation-fade;">
        <div class="uk-text-center">
    <div class="uk-inline-clip uk-transition-toggle uk-light livehealthy  card gradient" tabindex="0">
        <img src="img/obesity.jpg" alt="">
        <div class="uk-position-center">
            <div class="uk-transition-slide-top-small"><h4 class="">Obesity</h4></div>
            <div class="uk-transition-slide-bottom-small"><h4 class="uk-margin-remove">
              <button class="uk-button uk-button-default">
                View Test
              </button>
            </h4></div>
        </div>
    </div>
</div>
</div>
<div class="uk-width-1-3 uk-margin-remove"  uk-scrollspy="cls: uk-animation-fade;">
  <div class="uk-text-center">
<div class="uk-inline-clip uk-transition-toggle uk-light livehealthy  card gradient" tabindex="0">
  <img width="100%" src="img/kidny.jpeg" alt="">
  <div class="uk-position-center">
      <div class="uk-transition-slide-top-small"><h4 class="">Kidney</h4></div>
      <div class="uk-transition-slide-bottom-small"><h4 class="uk-margin-remove">
        <button class="uk-button uk-button-default">
          View Test
        </button>
      </h4></div>
  </div>
</div>
</div>
</div>
<div class="uk-width-1-3 uk-margin-remove"  uk-scrollspy="cls: uk-animation-fade;">
  <div class="uk-text-center">
<div class="uk-inline-clip uk-transition-toggle uk-light livehealthy  card gradient" tabindex="0">
  <img src="img/drug-liver-disease-mice-1.jpg" alt="">
  <div class="uk-position-center">
      <div class="uk-transition-slide-top-small"><h4 class="">liver disease</h4></div>
      <div class="uk-transition-slide-bottom-small"><h4 class="uk-margin-remove">
        <button class="uk-button uk-button-default">
          View Test
        </button>
      </h4></div>
  </div>
</div>
</div>
</div>
<div class="uk-width-1-3 uk-margin-remove"  uk-scrollspy="cls: uk-animation-fade;">
  <div class="uk-text-center">
<div class="uk-inline-clip uk-transition-toggle uk-light livehealthy  card gradient" tabindex="0">
  <img src="img/diabetes.jpg" alt="">
  <div class="uk-position-center">
      <div class="uk-transition-slide-top-small"><h4 class="">Sugar disease</h4></div>
      <div class="uk-transition-slide-bottom-small"><h4 class="uk-margin-remove">
        <button class="uk-button uk-button-default">
          View Test
        </button>
      </h4></div>
  </div>
</div>
</div>
</div>
<div class="uk-width-1-3 uk-margin-remove"  uk-scrollspy="cls: uk-animation-fade;">
  <div class="uk-text-center">
<div class="uk-inline-clip uk-transition-toggle uk-light livehealthy  card gradient" tabindex="0">
  <img src="img/Autoimmue.jpeg" alt="">
  <div class="uk-position-center">
      <div class="uk-transition-slide-top-small"><h4 class="">Auto immune disease</h4></div>
      <div class="uk-transition-slide-bottom-small"><h4 class="uk-margin-remove">
        <button class="uk-button uk-button-default">
          View Test
        </button>
      </h4></div>
  </div>
</div>
</div>
</div>
<div class="uk-width-1-3 uk-margin-remove"  uk-scrollspy="cls: uk-animation-fade;">
  <div class="uk-text-center">
<div class="uk-inline-clip uk-transition-toggle uk-light livehealthy  card gradient" tabindex="0">
  <img src="img/anemia.jpeg" alt="">
  <div class="uk-position-center">
      <div class="uk-transition-slide-top-small"><h4 class="">Anemia</h4></div>
      <div class="uk-transition-slide-bottom-small"><h4 class="uk-margin-remove">
        <button class="uk-button uk-button-default">
          View Test
        </button>
      </h4></div>
  </div>
</div>
</div>
</div>
<div class="uk-width-1-3 uk-margin-remove"  uk-scrollspy="cls: uk-animation-fade;">
  <div class="uk-text-center">
<div class="uk-inline-clip uk-transition-toggle uk-light livehealthy  card gradient" tabindex="0">
  <img src="img/infla.jpeg" alt="">
  <div class="uk-position-center">
      <div class="uk-transition-slide-top-small"><h4 class="">Inflammation</h4></div>
      <div class="uk-transition-slide-bottom-small"><h4 class="uk-margin-remove">
        <button class="uk-button uk-button-default">
          View Test
        </button>
      </h4></div>
  </div>
</div>
</div>
</div>
<div class="uk-width-1-3 uk-margin-remove" uk-scrollspy="cls: uk-animation-fade;">
  <div class="uk-text-center">
<div class="uk-inline-clip uk-transition-toggle uk-light livehealthy  card gradient" tabindex="0">
  <img src="img/maxresdefault.jpg" alt="">
  <div class="uk-position-center">
      <div class="uk-transition-slide-top-small"><h4 class="">Coagulation</h4></div>
      <div class="uk-transition-slide-bottom-small"><h4 class="uk-margin-remove">
        <button class="uk-button uk-button-default">
          View Test
        </button>
      </h4></div>
  </div>
</div>
</div>
</div>

      </div>
    </div>
  </div>
</section>


<section class="section"  uk-scrollspy="cls: uk-animation-fade;">
  <div class="uk-container" >
    <div class="uk-text-center">
      <h1>Medical Advices</h1>
      <hr class="hr hr_margin_auto">
    </div>
    <br>
    <div>
        <div uk-grid>
            <div class="uk-width-auto@m">
                <ul class="uk-tab-left" uk-tab="connect: #component-tab-left; animation: uk-animation-fade">
                    <li><a href="#">H. Pylori </a></li>
                    <li><a href="#">Sugar</a></li>
                    <li><a href="#">Water</a></li>
                    <li><a href="#">HyperTension</a></li>
                </ul>
            </div>
            <div class="uk-width-expand@m">
                <ul id="component-tab-left" class="uk-switcher">

                  <li>
                  <p>50 % &nbsp;Of the world's adults have H. Pylori</p>

                  <p>Most people do not feel sick until the condition develops</p>

                  <h3>Some of the symptoms that a patient may feel:</h3>

                  <ul>
                  	<li>abdominal pain</li>
                  	<li>nausea</li>
                  	<li>vomit</li>
                  	<li>Feeling bloating and gases</li>
                  	<li>Weight loss</li>
                  </ul>

                  <h3>What do you eat if you get H. Pylori?</h3>

                  <ul>
                  	<li>Most of the fruits and vegetables, especially those that contain vitamin C.</li>
                  	<li>Drink more water</li>
                  	<li>Eat cereals and legumes such as oats and beans</li>
                  	<li>Add cinnamon, cloves and garlic to your diet</li>
                  	<li>Replace the coffee with green tea</li>
                  	<li>Take honey from the morning</li>
                  </ul>

                  <h3>Avoid</h3>

                  <ul>
                  	<li>Milk and whole fat</li>
                  	<li>Chocolate</li>
                  	<li>refined flour (white)</li>
                  	<li>Sugars and soft drinks</li>
                  	<li>Beware salted and smoked foods</li>
                  	<li>fried food</li>
                  </ul>

                  <h3><span dir="LTR">For diagnosis&nbsp; : </span></h3>

                  <ul>
                  	<li>Ag in Stool</li>
                  	<li>Ab ( IgG –IgM – IgA )</li>
                  	<li>Urea breath test</li>
                  	<li>Helicobacter line test</li>
                  	<li>Biopsy</li>
                  </ul>
</li>
<li>

  <p><strong>Types:</strong></p>

  <p>• <strong>Type I:</strong> Young children and young people usually fall under 20 years and is caused by the inability of the pancreas to secrete insulin</p>

  <p>• <strong>Type 2:</strong> the most common type and accounts for 90% of patients with diabetes</p>

  <p>The most common type in adults over 40 years or overweight</p>

  <p>Is caused by the inability of the body to secrete sufficient amount of insulin hormone or the presence of sufficient amount of insulin, but not effective, resulting in high blood sugar</p>

  <h3>Symptoms of Diabetes:</h3>

  <p>• Extreme thirst</p>

  <p>• Delayed wound healing</p>

  <p>• Heat in the feet</p>

  <p>• Frequent urination</p>

  <p>• Tiredness and exhaustion Difficulty concentrating</p>

  <p>• Skin infections</p>

  <p>• Pain and numbness in the limbs</p>

  <p>• Weight loss</p>

  <p>• Disorders of vision</p>

  <h3><span dir="LTR">For diagnosis :</span></h3>

  <ul>
  	<li>FBS- 2Hr PP -&nbsp; Random Blood Sugar</li>
  	<li>Insulin (FBS- 2Hr PP )</li>
  	<li>C- peptide</li>
  	<li>Anti insulin Ab</li>
  	<li>Anti –islet Ab</li>
  	<li>Homa IR</li>
  </ul>

  <h3><span dir="LTR">For follow up :</span></h3>

  <ul>
  	<li>FBS- 2Hr PP</li>
  	<li>HbA1c</li>
  	<li>Microalbuminuria / e GFR/cystatin C</li>
  	<li>Lipid profile</li>
  	<li>CK- MB / Trophnine / LDH</li>
  </ul>

</li>
<li>
<h3>Water is a major component: represents</h3>

<ul>
	<li>75% of brain size</li>
	<li>92% of blood volume</li>
	<li>75% of the muscles</li>
	<li>22% of bone</li>
</ul>

<p>Therefore, the individual should drink&nbsp;8 glasses of water as an average</p>

<p>Water intake should be increased in cases of exercise, summer, illness, pregnancy and lactation</p>

<p>Morning advice: Drink a glass of water daily as you wake up</p>

<h3>Benefits of water for the human body:</h3>

<ul>
	<li>Maintains the freshness and vitality of the skin</li>
	<li>Weight loss</li>
	<li>Important for the kidneys, intestines, bones, muscles, brain, lungs, blood and eye</li>
</ul>

<h3>Lack of drinking water causes:</h3>

<ul>
	<li>Fatigue and stress</li>
	<li>High blood pressure</li>
	<li>Increase asthma and allergies</li>
	<li>Skin problems due to dehydration</li>
	<li>Helps to increase cholesterol</li>
	<li>Problems with kidney and bladder</li>
	<li>Problems in digestion</li>
	<li>Joint pain</li>
	<li>The effects of aging progress rapidly</li>
</ul>
</li>


                    <li>

                      <p>Is the increased pressure on the walls of the arteries, which regulate the amount of blood passing through the expansion and regular contraction with the heartbeat If these arteries lost flexibility for any reason then increase the resistance of arteries to blood circulation and&nbsp;raise blood pressure and therefore the resistance of arterial walls of blood circulation is an important factor To determine the level of blood pressure and control</p>

                      <h3>Types of blood pressure:</h3>

                      <p>There are two types of pressure being measured</p>

                      <p>Systolic pressure is measured when the heart contracts during the pumping process</p>

                      <p>Diastolic pressure is measured when the heart relaxes to receive the blood coming from the body</p>

                      <p>Normal range of blood pressure:</p>

                      <p>Systolic pressure 120</p>

                      <p>Diastolic pressure 80</p>

                      <h3>Reasons:</h3>

                      <p>Hypertension has two main types:</p>

                      <p>• <strong>Type I</strong>: is the most widespread in the world and does not know the cause of a certain occurrence</p>

                      <p>• <strong>Type II</strong>: This occurs because of a disease that leads to high pressure such as kidney disease or aorta or some diseases of the glands of silence or the use of some medications</p>

                      <h3>Risk factors:</h3>

                      <p>There are a number of factors that increase the proportion of pressure disease, including the following:</p>

                      <p>• Age</p>

                      <p>• Increase the intake of foods containing sodium and reduce the intake of foods containing potassium</p>

                      <p>•Genetic factors</p>

                      <p>•Lack of exercise</p>

                      <p>• Smoking <span dir="RTL">&nbsp;&nbsp;&nbsp;&amp;</span>Stress</p>

                      <h3>Symptoms:</h3>

                      <p>Usually, people with high blood pressure do not show any symptoms but some patients may feel the following:</p>

                      <p>• headache</p>

                      <p>• vertigo</p>

                      <p>• Shortness of breath</p>

                      <p>• More nasal bleeding than usual</p>

                      <h3><span dir="LTR">For diagnosis :</span></h3>

                      <ul>
                      	<li>Renin</li>
                      	<li>Dopamine</li>
                      	<li>Aldosterone</li>
                      	<li>Catecholamine ( Adrenaline – Noradrenaline )</li>
                      	<li>ACTH – Cortisol</li>
                      	<li>ADH</li>
                      </ul>


                    </li>
                    <li>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</li>
                    <li>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur, sed do eiusmod.</li>
                </ul>
            </div>
        </div>
      </div>
    </div>
</section>
<section  uk-scrollspy="cls: uk-animation-fade;">
  <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d110537.37665974897!2d31.088055931739696!3d30.028450311464027!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14583f9c3f5ad639%3A0x755e8b0d6e6135d0!2sINETWORK+Middle+East+LLC!5e0!3m2!1sen!2seg!4v1545059624786" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
</section>
<?php include'footer.php'; ?>
