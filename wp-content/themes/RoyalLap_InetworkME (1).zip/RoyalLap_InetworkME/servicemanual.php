<?php /* Template Name: Service Manual Page */ ?>
<?php include'header.php'; ?>
<?php include'herosection.php'; ?>
<div class="uk-container">
<section class="uk-padding-large">

  <?php the_field('service_manual'); ?>
</section>

</div>

<?php include'footer.php'; ?>
